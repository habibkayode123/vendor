export const herouke = "https://procurementsolution.herokuapp.com";
