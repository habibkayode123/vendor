import React from "react";

function Home() {
	return (
		<div className="page">
			<h1>car45</h1>
			<p>Welcome to Car45 home Page</p>
		</div>
	);
}

export default Home;
