import React from "react";


export default function BudgetUpload() {
	return <div>Budget Upload Interface</div>;
}
